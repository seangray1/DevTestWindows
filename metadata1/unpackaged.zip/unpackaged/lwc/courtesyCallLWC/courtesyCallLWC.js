/**
 * @File Name          : courtesyCallLWC.js
 * @Description        : 
 * @Author             : Sean Gray
 * @Group              : 
 * @Last Modified By   : Sean Gray
 * @Last Modified On   : 1/30/2020, 2:54:08 PM
 * @Modification Log   : 
 * Ver       Date            Author      		    Modification
 * 1.0    1/30/2020   Sean Gray     Initial Version
**/
import { LightningElement} from 'lwc';
// import { getObjectInfo } from 'lightning/uiObjectInfoApi';
//import { getPicklistValues } from 'lightning/uiObjectInfoApi';

//import COURTESYCALL_FIELD from '@salesforce/schema/Case.Case_Type__c';
// import CASE_OBJECT from '@salesforce/schema/Case';

export default class CourtesyCallLWC extends LightningElement {
    // @track Notes;
    // @track data;
    // @track CourtesyCallOutcome = "None";
    //@api recordId;
    // @wire(getObjectInfo, { objectApiName: CASE_OBJECT })
    // objectInfo;
    // @wire(getPicklistValues, { recordTypeId: '0120g000000EAlyAAG', fieldApiName: COURTESYCALL_FIELD})
    // CourtesyCallPicklistValues;
    
    // CourtesyCallChange(e){
        
    // }


}